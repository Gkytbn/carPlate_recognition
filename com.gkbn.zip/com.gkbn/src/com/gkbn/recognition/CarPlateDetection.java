package com.gkbn.recognition;


public class CarPlateDetection {
	
//	static {
////	    	System.out.println("hahhahaha");
//	    	System.loadLibrary("recognition");
////	        System.loadLibrary("recognition");
////	     //   System.loadLibrary("opencv_java3");
//	}
	
	public static native byte[] CarRecogize(String imgpath, String svmpath, String annpath);
}
