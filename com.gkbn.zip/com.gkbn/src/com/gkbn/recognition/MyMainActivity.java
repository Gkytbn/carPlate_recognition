package com.gkbn.recognition;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;

import com.gkbn.recognition.CameraView.TakePictureListener;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MyMainActivity extends Activity implements TakePictureListener {
	private ImageView imageView = null;
	private Bitmap bmp = null;
	private TextView m_text = null;
	private String path = Environment.getExternalStorageDirectory().getAbsolutePath();
	public final static int TAKE_PHOTO = 1;
	public final static int TAKE_PICTURE = 2;
	private Uri uri;
	private CameraView cameraView;

	String svmpath = path + "/svm.xml";
	String annpath = path + "/ann.xml";
	private Camera camera;
	private TextView myshow;
	String imgPathSave = path + "/com.gkbn/temp";
//	String imgPath = path + "/" + "temp.jpg";
	String imgPath = path + "/com.gkbn/temp/" + "temp.jpg";

	
	
	static {
	    if (!OpenCVLoader.initDebug()) {
	    	
	    } else {
	        System.loadLibrary("recognition");
	    }
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main2);

		imageView = (ImageView) findViewById(R.id.image_view);
		myshow = (TextView) findViewById(R.id.myshow);
		cameraView = (CameraView) findViewById(R.id.cameraView);
		m_text = (TextView) findViewById(R.id.myshow);
		bmp = BitmapFactory.decodeResource(getResources(), R.drawable.plate_locate);
		// imageView.setImageBitmap(bmp);
		cameraView.setTakePictureListener(this);
	}
	
	
	private BaseLoaderCallback mLoaderCallback = new BaseLoaderCallback(this) {
		@Override
		public void onManagerConnected(int status) {
			switch (status) {
			case LoaderCallbackInterface.SUCCESS: {
			}
				break;
			default: {
				super.onManagerConnected(status);
			}
				break;
			}
		}
	};

	@Override
	protected void onResume() {
		super.onResume();
		mLoaderCallback.onManagerConnected(LoaderCallbackInterface.SUCCESS);
	}

	private void Reco(String pathbytedata) {

		// // String imgpath = path+"/test7.jpg";
		// // // byte[] resultByte =
		// // CarPlateDetection.ImageProc(imgpath,svmpath,annpath);
		// // String result = new String(resultByte,"GBK");
		// // System.out.println(result);
		// // m_text.setText(result);
		//
		// BufferedInputStream in = null;
		// try {
		// in = new BufferedInputStream(new FileInputStream(pathbytedata));
		// } catch (FileNotFoundException e1) {
		// // TODO Auto-generated catch block
		// e1.printStackTrace();
		// }
		// ByteArrayOutputStream out = new ByteArrayOutputStream(1024);
		//
		// byte[] temp = new byte[1024];
		// int size = 0;
		// try {
		// while ((size = in.read(temp)) != -1) {
		// out.write(temp, 0, size);
		// }
		// } catch (IOException e1) {
		// // TODO Auto-generated catch block
		// e1.printStackTrace();
		// }
		// try {
		// in.close();
		// } catch (IOException e1) {
		// // TODO Auto-generated catch block
		// e1.printStackTrace();
		// }
		// byte[] content = out.toByteArray();
		//
		// byte[] temp2 = null;
		// try {
		// temp2 = CarPlateDetection.ImageProc(content, svmpath, annpath);
		// } catch (Exception e) {
		// // TODO: handle exception
		// }
		// String result = null;
		// try {
		// result = new String(temp2, "GBK");
		// } catch (UnsupportedEncodingException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		//
		// System.out.println(result);
	}

	public void cilck(View v) {

		camera.startPreview();
	}

	/** 保存方法 */
	public void saveBitmap(byte[]  bitmap) {
		Log.e("gkbn", "保存图片");
		
		File file = new File(imgPathSave);
		if (!file.exists()) {
			file.mkdirs();
		}
//		
		File f = new File(imgPath);
//		if (f.exists()) {
//			f.delete();
//		}else{
//			
//		}
		Bitmap bm = decodeSampledBitmapFromResource(bitmap, 300, 300);
		try {
			FileOutputStream out = new FileOutputStream(f);
			bm.compress(Bitmap.CompressFormat.PNG, 100, out);
			out.flush();
			out.close();
			Log.i("gkbn", "已经保存");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void SoomthIMG(byte[] bitmap) {

		File file = new File(imgPathSave);
		if (!file.exists()) {
			file.mkdirs();
		}

		Bitmap bm = decodeSampledBitmapFromResource(bitmap, 1500, 500);

		ByteArrayOutputStream baos = new ByteArrayOutputStream();

		FileOutputStream fos = null;

		try {

			fos = new FileOutputStream(imgPath);

			if (null != fos)

			{

				bm.compress(Bitmap.CompressFormat.JPEG, 100, baos);

				fos.flush();

				fos.close();

			}

		} catch (FileNotFoundException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	@Override
	public void onTakePicture(Bitmap bitmap, Camera camera) {
		// camera.stopPreview();
	//	imageView.setImageBitmap(bitmap);
	}

	boolean first=true;
	@Override
	public void onTakePicture(byte[] bitmap, Camera camera) {
		camera.stopPreview();
//		if(first){
		myshow.setText("开始检测");
		saveBitmap(bitmap);
		byte[] temp2 = null;
		String imgPath = path+"/plate_locate.jpg";
		try {
			temp2 = CarPlateDetection.CarRecogize(imgPath, svmpath, annpath);
		} catch (Exception e) {
		}
		String result = null;
		try {
			result = new String(temp2, "GBK");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		myshow.setText(result);
		System.out.println(result);
		first=false;
//		}
	}

	public static Bitmap decodeSampledBitmapFromResource(byte[] res, int reqWidth, int reqHeight) {

		// First decode with inJustDecodeBounds=true to check dimensions
		final BitmapFactory.Options options = new BitmapFactory.Options();
		options.inJustDecodeBounds = true;
		BitmapFactory.decodeByteArray(res, 0, res.length, options);

		// Calculate inSampleSize
		options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);

		// Decode bitmap with inSampleSize set
		options.inJustDecodeBounds = false;
		return BitmapFactory.decodeByteArray(res, 0, res.length, options);
	}

	public static int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
		// Raw height and width of image
		final int height = options.outHeight;
		final int width = options.outWidth;
		int inSampleSize = 1;

		if (height > reqHeight || width > reqWidth) {

			final int halfHeight = height / 2;
			final int halfWidth = width / 2;

			// Calculate the largest inSampleSize value that is a power of 2 and
			// keeps both
			// height and width larger than the requested height and width.
			while ((halfHeight / inSampleSize) > reqHeight && (halfWidth / inSampleSize) > reqWidth) {
				inSampleSize *= 2;
			}
		}

		return inSampleSize;
	}

}
